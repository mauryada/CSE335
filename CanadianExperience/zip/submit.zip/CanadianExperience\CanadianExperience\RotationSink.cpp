#include "stdafx.h"
#include "RotationSink.h"


CRotationSink::CRotationSink()
{
}


CRotationSink::~CRotationSink()
{
}
